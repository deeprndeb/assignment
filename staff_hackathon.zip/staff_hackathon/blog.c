#include<stdio.h>
#include"blog.h"

void public_blog()
{
	printf("\n -----------------------------------Public Blog-------------------------------------\n");
	blog_t b;
	FILE *fp = fopen("blogs.txt","r");
	while(fread(&b,sizeof(b),1,fp))
	{
		if(strcmp("public",b.cat) == 0)
		{
			printf("\n Blog ID: %d ",b.bid);
			printf("\t Blog Title : %s",b.title);
			printf("\t Ownwr : %s ",b.own);
		}
	}

	fclose(fp);
	printf("\n");
}
void shared_blog()
{
	printf("\n -----------------------------------Shared Blog----------------------------------------\n");
	share_t s;
	FILE *fp = fopen("shared.txt","r");
	if(fp != NULL)
	{
		while(fread(&s,sizeof(s),1,fp))
		{
			if((strcmp(s.sh_id,owner)) == 0)
			{
				printf("\n Blog ID: %d ",s.id);
				printf("\t Blog Title : %s",s.title);
				printf("\t Owner : %s ",s.shr_id);
			}
		}
	}
	else
	{
		printf("\n Failed To Open File");
	}

	fclose(fp);
}

void private_blog()
{
	printf("\n ---------------------------------Private Blog-------------------------------------------\n");
	blog_t b;
	FILE *fp = fopen("blogs.txt","r");
	if(fp != NULL)
	{
		while(fread(&b,sizeof(b),1,fp))
		{
			if((strcmp(b.own,owner)) == 0)
			{
				if((strcmp(b.cat,"private")) == 0)
				{
					printf("\n Blog ID: %d ",b.bid);
					printf("\t Blog Title : %s",b.title);
					printf("\t Owner : %s ",b.own);
					printf("\t category: %s",b.cat);
				}
			}
		}
	}
	else
	{
		printf("\n Failed To Open File");
	}

	fclose(fp);
}
void my_blog()
{
	printf("\n ----------------------------------My Blogs-------------------------------------------------\n");
	blog_t b;
	FILE *fp = fopen("blogs.txt","r");
	while(fread(&b,sizeof(b),1,fp))
	{


		if(strcmp(owner,b.own)==0 )
		{
			printf("\n Blog ID: %d\n",b.bid );
			printf("\t Blog Title : %s",b.title );
			printf("\t Category : %s",b.cat );
			printf("\t Owner : %s\n",b.own );

			}
	}

	//fclose(fp);
	share_t s;
	FILE *sp = fopen("shared.txt","r");
	while(fread(&s,sizeof(s),1,sp))
	{
		if((strcmp(owner,s.sh_id))==0 )
		{
			printf("\n Blog ID: %d",s.id);
			printf("\t Blog Title : %s",s.title);
			printf("\t Owner : %s ",s.shr_id);
			printf("\t Category: shared");
		}
	}

	fclose(sp);
	fclose(fp);
}
void add_blog()
{
	printf("\n ----------------------------------Add Blogs-------------------------------------------------\n");
	char ch,c;
	blog_t b,t;
	FILE *fp = fopen("blogs.txt","r+");
	while(fread(&t,sizeof(t),1,fp));
	if(t.bid > 1000){
		t.bid = 0;
	}
	b.bid = t.bid +1;

	printf("\n Title :");
	scanf("%c",&ch);
	scanf("%[^\n]",b.title);
	printf("\n Content :");
	scanf("%c",&ch);
	scanf("%[^\n]",b.content);
	printf("\n category(private/public) :");
	scanf("%c",&ch);
	scanf("%[^\n]",b.cat);
	printf("\n File Path :");
	scanf("%c",&ch);
	scanf("%s",b.f_path);
	strcpy(b.own,owner);

	fwrite(&b,sizeof(b),1,fp);
	FILE *blp = fopen(b.f_path,"a");
	fwrite(&b.content,sizeof(b.content),1,blp);
	fclose(blp);
	int i;
	fclose(fp);
	printf("\n -----------------------------------------------------------------------------------------\n");
	display_all();
}
void search_blog()
{
	printf("\n --------------------------------Search Blog-------------------------------------------------\n");
	blog_t b;
	char ch,name[10];
	int i,flag = 0;
	scanf("%c",&ch);
	printf("Enter Blog Name to search : ");
	scanf("%[^\n]",name);
	FILE *fp = fopen("blogs.txt","r");
	while(fread(&b,sizeof(b),1,fp))
	{
		if(strcmp(name,b.title) == 0)
		{
			flag = 1;
			scanf("%c",&ch);
			printf("\n Blog Found : \n");
			printf("\n Blog Title: %s",b.title);
			printf("\n Blog Category: %s",b.cat);
			printf("\n Enter 1 To read Blog 0 to exit: ");
			scanf("%d",&i);
			if(i == 1)
			{
				printf("\n--------------------------------------------------------------------------\n");
				detail_blog(&b);

			}
			//fclose(fp);
			break;
		}
	}
	if(flag !=1)
	{
		printf("\n Blog Not Found !!");
	}

	fclose(fp);

}
void detail_blog(blog_t *b)
{
	char cont[20];
	printf("\n Blog Detail\n");
	FILE *blp = fopen(b->f_path,"r");

	if( strcmp(owner,b->own) == 0)
	{
		while(fread(cont,sizeof(cont),1,blp))
		{
			printf("%s",cont);
		}
		//fclose(blp);
	}
	else
	{
		if( strcmp(b->cat,"private") == 0)
		{
			printf("\n Could Not read The Blog...");
			printf("\n Blog is PRIVATE...");
		}
		else
		{
			while(fread(cont,sizeof(cont),1,blp))
			{
				printf("%s",cont);
			}

		}

	}
fclose(blp);
}
void logout()
{
	printf("Bye...");
}

void edit()
{
	printf("\n ----------------------------------------Edit Blog----------------------------------------------------------\n");
	blog_t b;
	char ch,name[10];
	int i,flag = 0,flag2 = 0;
	scanf("%c",&ch);
	printf("Enter Blog Title to Edit : ");
	scanf("%[^\n]",name);
	printf("\n %s",owner);
	FILE *fp = fopen("blogs.txt","r+");
	while(fread(&b,sizeof(b),1,fp))
	{
		if(strcmp(name,b.title)==0)
		{
			flag2 = 1;
			if(strcmp(owner,b.own) == 0)
			{
				flag = 1;
				int i = 1;
				while(i != 0)
				{
					printf("\n PRESS 0.Exit \n PRESS1. Edit Title \n PRESS 2. Edit Content \n Enter Your Choice:");
					scanf("%d",&i);
					switch(i)
					{
						case 1: printf("\n Enter New Title: ");
								scanf("%c",&ch);
								scanf("%[^\n]",b.title);
								break;

						case 2: edit_cont(&b);
								break;
					}
				}
				if( fseek(fp,-sizeof(b),SEEK_CUR) == 0)
				{
					fwrite(&b,sizeof(b),1,fp);
				}
				else
				{
					printf("\nFailed To Edit");
				}

			//	fclose(fp);
				break;
			}
		}

	}
	if(flag2 ==0 )
	{
		printf("\n Blog NOT Found !!");
	}
	if(flag2 == 1 && flag == 0)
	{
		 printf("\n Blog Found !!");
		printf("\n USER NOT HAVING PERMISSIONS TO MODIFY BLOG \n");
	}

	fclose(fp);

}

void display_all()
{
	printf("\n ALL BLOGS \n");
	printf("\n -------------------------------------------------------------------------\n");
	blog_t b;
	FILE * fp = fopen("blogs.txt","r");

	while(fread(&b,sizeof(b),1,fp))
	{
		printf("\n  ID: %d",b.bid);
		printf("\t  Title : %s ",b.title);
		printf("\t  Category : %s ",b.cat);
	}

	fclose(fp);
}

void edit_cont(blog_t *b)
{
	FILE * fp = fopen(b->f_path,"a");
	char ch, cont[20];

	printf("\n Enter New Content To Modify : ");
	scanf("%c",&ch);
	scanf("%[^\n]",cont);

	fwrite(&cont,sizeof(cont),1,fp);

	fclose(fp);
}
void delete_blog()
{
	blog_t b;
	char ch, name[10],f_path[10];
	FILE *fp = fopen("blogs.txt","r");
	FILE *tp = fopen("temp.txt","a");
	while(fread(&b,sizeof(b),1,fp))
	{
		if((strcmp(owner,b.own))==0 )
		{
			printf("\n Blog ID: %d",b.bid);
			printf("\t Blog Title : %s",b.title);
			printf("\t Owner : %s ",b.own);
			printf("\t Category: %s",b.cat);
		}
	}
	fclose(fp);
	scanf("%c",&ch);
	FILE *fp1 = fopen("blogs.txt","r");
	printf("\n Enter Blog Name To delete: ");
	scanf("%[^\n]",name);
	while(fread(&b,sizeof(b),1,fp1))
	{
		if((strcmp(b.title,name)) != 0 )
		{
			fwrite(&b,sizeof(b),1,tp);
		}
		else
		{
			strcpy(f_path,b.f_path);
		}
	}

	fclose(fp1);
	fclose(tp);
	remove("blogs.txt");
	remove(f_path);
	rename("temp.txt","blogs.txt");
}

void share_blog()
{

	printf("\n -----------------------------------------Share Blog------------------------------------------------------\n");
	private_blog();
	blog_t b;
	char ch,name[10];
	int i,flag = 0;
	scanf("%c",&ch);
	printf("Enter Blog Name to share : ");
	scanf("%[^\n]",name);
	FILE *fp = fopen("blogs.txt","r");
	while(fread(&b,sizeof(b),1,fp))
	{
		if(strcmp(name,b.title) == 0)
		{
			share_t s;
			s.id = b.bid;
			printf("\n Enter User Name to Share Blogs : ");
			scanf("%c",&ch);
			scanf("%s",s.sh_id);
			strcpy(s.shr_id,owner);
			strcpy(s.title,b.title);

			FILE *sp = fopen("shared.txt","a");
			fwrite(&s,sizeof(s),1,sp);
			fclose(sp);

		}
	}
	fclose(fp);
}
