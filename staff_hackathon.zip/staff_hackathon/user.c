#include<stdio.h>
#include"user.h"
#include"blog.h"

typedef struct usr{
	int uid;
	char email[30];
	char pass[15];
	char name[30];
	int phone;
}usr_t;

extern char owner[30];

int user_login()
{
	char ch,c,email[30],pass[10];
	int i,j,k;
	usr_t u;
	
	printf("\n ------------------------------WELCOME TO MY BLOG APP------------------------------------------------------");
	printf("\n ------------------------------------User Login-------------------------------------------------------");
	FILE *fp = fopen("user.txt","r");
	scanf("%c",&ch);
	printf("\n Email : ");
	scanf("%s",email);
	scanf("%c",&ch);
	printf("\n Password: ");
	scanf("%s",pass);
	scanf("%c",&ch);

	printf("\n Enter C  to continue \n Enter E to exit :");
	scanf("%c",&c);
	if(c == 'c' || c == 'C')
	{
		while(fread(&u,sizeof(u),1,fp))
		{
			if(((strcmp(email,u.email)) ||(strcmp(pass,u.pass))) == 0)
			{
				printf("Login Successfull");
				printf("\n -----------------------------------------------------------------\n");
				strcpy(owner,u.email);
				fclose(fp);
				return 1;
			}
		}
	}
	fclose(fp);
	return 0;
}
void user_register()
{
	usr_t u;
	char ch,c;
	//u.id = 0;
	printf("\n ---------------------------------User Registration---------------------------------------------------");
	FILE *fp = fopen("user.txt","r+");
	while(fread(&u,sizeof(u),1,fp));
	u.uid ++;
	scanf("%c",&ch);
	printf("\n Email: ");
	scanf("%s",u.email);
	scanf("%c",&ch);
	printf("\n password: ");
	scanf("%s",u.pass);
	scanf("%c",&ch);
	printf("\n FULL NAME: ");
	scanf("%[^\n]",u.name);
	printf("\n Phone : ");
	scanf("%d",&u.phone);
	scanf("%c",&ch);

	printf("\n Enter C  to continue \n Enter E to exit :");
	scanf("%c",&c);
	if(c == 'c' || c == 'C')
	{
		fwrite(&u,sizeof(u),1,fp);
		fclose(fp);
	}
}
