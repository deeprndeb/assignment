#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct blog_details{
	int bid;
	char title[10];
	char content[20];
	char f_path [20];
	char cat[10];
	char own[30];
}blog_t;

typedef struct shared_detail{
	int id;
	char sh_id[30];
	char shr_id[30];
	char title[10];
}share_t;

char owner[30];
void public_blog();
void shared_blog();
void private_blog();
void my_blog();
void add_blog();
void search_blog();
void detail_blog();
void logout();
void edit();
void edit_cont(blog_t *b);
void display_all();
void delete_blog();
void share_blog();
