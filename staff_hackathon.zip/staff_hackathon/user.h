#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int user_login();
void user_register();
