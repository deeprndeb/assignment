#include<stdio.h>
#include"user.h"
#include"blog.h"
int main()
{

	int  ch=1,flag=0;
	while(ch !=0)
	{
	printf("\n --------------------------MENU------------------------------------------\n");
		printf("\n PRESS 0. Exit \n PRESS 1. Login \n PRESS 2. Register");
		printf("\n Enter Your Choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: flag = user_login();
					if(flag == 1)
					{
						int i =1;
						while(i != 0)
						{
							printf("\n PRESS 0. LOGOUT \n PRESS 1. Add Blog \n PRESS 2. Public Blog \n PRESS 3. Shared Blogs \n PRESS 4. Private Blogs \n PRESS 5. My Blog \n PRESS 6. Search Blog \n PRESS 7. Edit Blog \n PRESS 8. Delete Blog \n PRESS 9. Share Blog");
							printf("\n Enter Your Choice : ");
							scanf("%d",&i);
							switch(i)
							{
								case 0: flag = 0;
										break;
								case 1: add_blog();
										break;
								case 2: public_blog();
										break;

								case 3: shared_blog();
										break;
								case 4: private_blog();
										break;
								case 5: my_blog();
										break;
								case 6: search_blog();
										break;
								case 7: edit();
										break;
								case 8 : delete_blog();
										 break;
								case 9: share_blog();
										break;
							}
						}
					}

					break;
			case 2: user_register();
					break;

		}
	}


	return 0;

}
