#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define TRUE 1
#define FALSE 0
typedef int bool;
int item_id;
typedef struct ITEM_DETAILS
{
	int item_id;
	char item_name[15];
	float item_price;
	int item_quantity;
}ITEM;

typedef struct node
{
	ITEM data;
	struct node *next;

}NODE;

typedef struct LinkedList
{
	NODE *head;
	NODE *tail;
}LIST;

typedef struct InventoryManagementSystem
{
	LIST item_list;

}ILIST;
typedef enum{EXIT,ADD,FIND,DISPLAY,EDIT,DELETE}MENU;
MENU menu_list();
void write_item_data_into_file(ILIST *inventory_list);
int sub_menu_list_for_delete();
void read_item_data_from_file(ILIST *inventory_list);
void accept_item_info(ITEM *item);
void print_item_info(const ITEM *item);
int sub_menu_list_for_search();
void init_inventory_list(ILIST *inventory_list);
void add_item(ILIST *inventory_list,ITEM *item);
void clear_inventory_list(ILIST *inventory_list);
void init_list(LIST *list);
bool is_empty(LIST *list);
void add_first(LIST *list,ITEM *item);
void add_last(LIST *list,ITEM *item);
NODE* search_by_id(LIST *list,ITEM *item);
NODE* search_by_name(LIST *list,ITEM *item);
void delete_first(LIST *list);
void delete_last(LIST *list);
int node_count(LIST *list,int *count);
void delete_node(LIST *list,NODE *node);
NODE* create_node();
bool delete_item_by_id(LIST *list,ITEM *item);
bool delete_item_by_name(LIST *list,ITEM *item);
void display_list(LIST *list);
void clear_list( LIST *const list );
void print_data(NODE *node);
ITEM search_item_by_id_in_list(ILIST *inventory_list,int item_id);
ITEM search_item_by_name_in_list(ILIST *inventory_list,char *name);
void delete_item_by_name_in_list( ILIST *inventory_list, char *name );
void delete_item_by_id_in_list( ILIST *inventory_list, int id );
void clear_inventory_list(ILIST *inventory_list);
void accept_id(int *id);
void print_item_in_list(ILIST *inventory_list);
void accept_name(char *name);
void edit_record(ILIST *inventory_list, int item_id);


int main(void)
{
	ITEM item;
	bool status;
	MENU choice;
	ILIST inventory_list;
	init_inventory_list(&inventory_list);
	read_item_data_from_file(&inventory_list);
	int id;
	char name[20];
	while((choice=menu_list())!=EXIT)
    {
    	switch(choice)
    	{
    	case ADD:
    			accept_item_info(&item);
    			add_item(&inventory_list,&item);
    			write_item_data_into_file(&inventory_list);
    			break;
    	case FIND:
    			while((choice=sub_menu_list_for_search())!=0)
    			{
    				switch(choice)
    				{
						case 1:
								accept_id(&id);
								item=search_item_by_id_in_list(&inventory_list,id);
								print_item_info(&item);
								break;
						case 2:accept_name(name);
								item=search_item_by_name_in_list(&inventory_list,name);
								print_item_info(&item);
								break;
						default:
								printf("\nInvalid choice..");
								continue;
    				}
    			}
    			break;
    	case DISPLAY:
    				print_item_in_list(&inventory_list);
    				//read_item_data_from_file();
    			break;
    	case EDIT:
    			accept_id(&id);
    			edit_record(&inventory_list,id);
    			write_item_data_into_file(&inventory_list);
    			break;
    	case DELETE:
				while((choice=sub_menu_list_for_delete())!=0)
				{
					switch(choice)
					{
						case 1:accept_id(&id);
								delete_item_by_id_in_list(&inventory_list,id);
								write_item_data_into_file(&inventory_list);
								break;
						case 2:accept_name(name);
								delete_item_by_name_in_list(&inventory_list,name);
								write_item_data_into_file(&inventory_list);
								break;
						default:
								printf("\nInvalid choice..");
								continue;
					}
				}
    			break;
    	default:
				printf("\n Invalid choice");
				break;

    	}

    }
	write_item_data_into_file(&inventory_list);
	clear_inventory_list(&inventory_list);
	return EXIT_SUCCESS;
}

void accept_id(int *id)
{
	printf("\nEnter the id	:	");
	scanf("%d",id);
}

void accept_name(char *name)
{
	printf("\nEnter the name	:	");
	scanf("%s",name);
}

MENU menu_list()
{
	MENU choice;
	printf("\n----------------MENU----------------------\n");
	printf("\nPRESS 0. EXIT");
	printf("\nPRESS 1. ADD ITEM");
	printf("\nPRESS 2. FIND ITEM");
	printf("\nPRESS 3. DISPLAY ITEM");
	printf("\nPRESS 4. EDIT ITEM");
	printf("\nPRESS 5. DELETE ITEM");
	printf("\n--------------------------------------------\n");
	printf("\nEnter your choice	:	");
	scanf("%d",&choice);

	return choice;
}
int sub_menu_list_for_delete()
{
	int choice;
	printf("\n-----------------DELETE MENU---------------------");
	printf("\n0.  EXIT");
	printf("\n1.  DELETE FROM ID");
	printf("\n2.  DELETE FROM NAME");
	printf("\nEnter your choice	:	");
	scanf("%d",&choice);

	return choice;


}
void write_item_data_into_file(ILIST *inventory_list)
{

	FILE *fpWrite=NULL;

	fpWrite=fopen("iteminfo.dat","wb");
	if(fpWrite==NULL)
		printf("\n unable to write info into file");
	else
	{
		NODE *trav=inventory_list->item_list.head;

		while( trav!= NULL )
		{
			fwrite(&trav->data, sizeof(ITEM), 1, fpWrite);
			trav = trav->next;
		}
		fclose(fpWrite);
	}
}

void read_item_data_from_file(ILIST *inventory_list)
{
	FILE *fpRead=NULL;

	fpRead=fopen("iteminfo.dat", "rb");
	if(fpRead==NULL)
		printf("\n unable to write empinfo into file");
	else
	{
		while( !feof(fpRead))
		{
			ITEM *item = ( ITEM* )malloc( sizeof( ITEM ) );
			fread(item, sizeof( ITEM ), 1, fpRead );
			if( !feof( fpRead ) )
				add_last(&inventory_list->item_list, item);
		}
		fclose(fpRead);

	}
}

void init_inventory_list(ILIST *inventory_list)
{
	init_list(&inventory_list->item_list);
}

void add_item(ILIST *inventory_list,ITEM *item)
{
	add_last(&inventory_list->item_list,item);
}

/*int available_item(int item_id)
{
	 ITEM item;
	 FILE *fpRead=NULL;
	 fpRead = fopen("iteminfo.dat", "rb");
	 rewind(fpRead);
	 while(fread(&item, sizeof(ITEM),1, fpRead))
	{
		 if (item_id == item.item_id)
		  {
		   fclose(fpRead);
		   return 1;
		  }

	 fclose(fpRead);
	 return 0;
}
}*/
void accept_item_info(ITEM *item)
{
	printf("\n------------Enter ItemInfo--------------\n");

	item->item_id=++item_id;
	fprintf(stdout,"\n Enter Item Name	:	");
	fscanf(stdin,"%s",item->item_name);

	fprintf(stdout,"\n Enter Item Price	:	");
	fscanf(stdin,"%f",&item->item_price);
	fprintf(stdout,"\n Enter Item Quantity	:	");
	fscanf(stdin,"%d",&item->item_quantity);
}
int sub_menu_list_for_search()
{
	int choice;
	printf("\n-----------------SEARCH MENU---------------------");
	printf("\n0. EXIT");
	printf("\n1. SEARCH BY ID");
	printf("\n2. SEARCH BY NAME");
	printf("\nEnter your choice	:	");
	scanf("%d",&choice);

	return choice;
}
void print_item_info(const ITEM *item)
{
	printf("\n %-5d %15s %10f %10d",item->item_id,item->item_name,item->item_price,item->item_quantity);
}
void init_list(LIST *list)
{
	list->head=NULL;
	list->tail=NULL;
}

bool is_empty(LIST *list)
{
	if(list->head==NULL)
		return TRUE;
	return FALSE;
}

void add_first(LIST *list,ITEM *item)
{
	NODE *newNode=create_node();
	if(newNode==NULL)
		printf("\n malloc() fails to allocate memory..");
	else
	{
		newNode->data.item_id=item->item_id;
		strcpy(newNode->data.item_name,item->item_name);
		newNode->data.item_price=item->item_price;
		newNode->data.item_quantity=item->item_quantity;
		if(is_empty(list))
			list->tail=newNode;
		else
			newNode->next=list->head;
		list->head=newNode;
	}
}

void add_last(LIST *list,ITEM *item)
{
	NODE *newNode=create_node();
	if(newNode==NULL)
		printf("\n malloc() fails to allocate memory..");
	else
	{
		newNode->data.item_id=item->item_id;
		strcpy(newNode->data.item_name,item->item_name);
		newNode->data.item_price=item->item_price;
		newNode->data.item_quantity=item->item_quantity;
		if(is_empty(list))
			list->head=newNode;
		else
			list->tail->next=newNode;
		list->tail=newNode;
	}
}
NODE* search_by_id(LIST *list,ITEM *item)
{
	if(!is_empty(list))
	{
		NODE* trav=list->head;
		while(trav!=NULL)
		{
			if(trav->data.item_id==item->item_id)
				return trav;
			trav=trav->next;
		}
	}
	return NULL;
}

NODE* search_by_name(LIST *list,ITEM *item)
{
	if(!is_empty(list))
	{
		NODE* trav=list->head;
		while(trav!=NULL)
		{
			if(strcmp(trav->data.item_name,item->item_name)==0)
				return trav;
			trav=trav->next;
		}
	}
	return NULL;
}

void delete_first(LIST *list)
{
	if(!is_empty(list))
	{
		if(list->head==list->tail)
		{
			free(list->head);
			list->head=list->tail=NULL;
		}
		else
		{
			NODE *temp=list->head;
			list->head=list->head->next;
			free(temp);
			temp=NULL;
		}

	}
}

void delete_last(LIST *list)
{
	if(!is_empty(list))
	{
		if(list->head==list->tail)
		{
			free(list->head);
			list->head=list->tail=NULL;
		}
		else
		{
			NODE *trav=list->head;
			while(trav->next!=list->tail)
				trav=trav->next;
			list->tail=trav;
			free(list->tail->next);
			list->tail->next=NULL;
		}
	}

}

/*int node_count(LIST *list,int *count)
{
	*count=1;
	if(!is_empty(list))
	{
		NODE *trav=list->head;
		while(trav!=NULL)
		{
			++*count;
			trav=trav->next;
			return *count;
		}
	}
	return NULL;
}*/

void delete_node(LIST *list,NODE *node)
{
	if(node==list->head)
		delete_first(list);
	else if(node==list->tail)
		delete_last(list);
	else
	{
		NODE *ptrNode = node->next;
		node->data.item_id=ptrNode->data.item_id;
		strcpy(node->data.item_name,ptrNode->data.item_name);
		node->data.item_price=ptrNode->data.item_price;
		node->data.item_quantity=ptrNode->data.item_quantity;
		//ptrNode->data = NULL;
		if( ptrNode == list->tail )
			delete_last(list);
		else
		{
			node->next = ptrNode->next;
			free(ptrNode);
		}
	}
}
NODE* create_node()
{
	NODE *temp=(NODE *)malloc(sizeof(NODE));
	if(temp!=NULL)
	{
		temp->next=NULL;
		return temp;
	}
	return NULL;
}

bool delete_item_by_id(LIST *list,ITEM *item)
{
	NODE *trav=list->head;
	while(trav!=NULL)
	{
		if(trav->data.item_id==item->item_id)
		//if(strcmp(trav->data.item_id,item->item_id)==0)

		{
			delete_node(list,trav);
			return TRUE;
		}
		trav=trav->next;

	}

	return FALSE;
}
bool delete_item_by_name(LIST *list,ITEM *item)
{
	NODE *trav=list->head;
	while(trav!=NULL)
	{
		if(strcmp(trav->data.item_name,item->item_name)==0)
		{
			delete_node(list,trav);
			return TRUE;
		}
		trav=trav->next;
	}
	return FALSE;
}

void display_list(LIST *list)
{
	if(!is_empty(list))
	{
		NODE *trav=list->head;
		while(trav!=NULL)
		{
			print_data(trav);
			trav=trav->next;
		}
	}
}

void clear_list( LIST *const list )
{
	while(!is_empty(list))
		delete_first(list);
}
void print_data(NODE *node)
{
	printf("\n %-3d %-20s %-2f %-3d",node->data.item_id,node->data.item_name
			,node->data.item_price,node->data.item_quantity);
}

ITEM search_item_by_id_in_list(ILIST *inventory_list,int item_id)
{
	ITEM item;
	item.item_id=item_id;
	NODE *temp=search_by_id(&inventory_list->item_list,&item);
	return temp->data;
}

ITEM search_item_by_name_in_list(ILIST *inventory_list,char *name)
{
	ITEM item;
	strcpy(item.item_name,name);
	NODE *temp=search_by_name(&inventory_list->item_list,&item);
	return temp->data;
}

void delete_item_by_name_in_list( ILIST *inventory_list, char *name )
{
	ITEM item;
	bool status;
	strcpy(item.item_name, name );
	status=delete_item_by_name(&inventory_list->item_list,&item);
	if(status==TRUE)
		printf("\nItem Removed Successfully..");
	else
		printf("\nItem Not Found");
}

void delete_item_by_id_in_list( ILIST *inventory_list, int id )
{
	ITEM item;
	bool status;
	item.item_id= id;
	//strcpy(item.item_id, &id);
	status=delete_item_by_id(&inventory_list->item_list,&item);
	if(status==TRUE)
		printf("\nItem Removed Successfully..");
	else
		printf("\nItem Not Found");
}

void clear_inventory_list(ILIST *inventory_list)
{
	clear_list( &inventory_list->item_list);
}

void edit_record(ILIST *inventory_list, int item_id)
{
	ITEM item;
	item.item_id=item_id;
	NODE *temp=search_by_id(&inventory_list->item_list,&item);
	printf("\n----------------Enter ItemInfo--------------------\n");
	printf("\n Item Id	:	%d",temp->data.item_id);
	printf("\n Item Name	:	%s",temp->data.item_name);
	printf("\n Enter New Name	:	");
	scanf("%s",temp->data.item_name);

	printf("\n Item Price	:	%f",temp->data.item_price);
	printf("\n Enter New price	:	");
	scanf("%f",&temp->data.item_price);

	printf("\n Item Quantity	:	%d",temp->data.item_quantity);
	printf("\n Enter Item  New Quantity	:	");
	scanf("%d",&temp->data.item_quantity);

}
void print_item_in_list(ILIST *inventory_list)
{

	display_list(&inventory_list->item_list);
}
