#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct acc_holder{
	char name[20];
	char address[50];
	int phone;
}holder;

typedef struct acc_detail{
	int id;
	char type[10];
	int balance;
	holder pers;
	struct acc_detail *next;
	struct acc_detail *prev;
}detail;


detail *head=NULL, *temp;

void add_first(detail *usr);
void add_last(detail *usr);
void display_fwd();
void display_back();

int main()
{
	int ch=1;
	detail data;
	while(ch !=0)
	{
		printf("\n 0. Exit\n 1. Add First \n 2. Add Last \n 3.Display Forward\n 4. Display Backward");
		printf("\n Enter choice: ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: add_first(head);
					break;
			case 2: add_last(head);
					break;
			case 3: display_fwd();
					break;
			case 4: display_back();
					break;
		}
	}
	return 0;
}

void add_last(detail *usr)
{
	int i;
	char ch;
	detail *data = (detail *)malloc(sizeof(detail));
	printf("\n Enter Id: ");
	scanf("%d",&data->id);
	scanf("%c",&ch);
	printf("\n Enter Acc Type: ");
	scanf("%s",data->type);
	printf("\n Enter Balance : ");
	scanf("%d",&data->balance);
	scanf("%c",&ch);
	printf("\n Enter Name: ");
	scanf("%[^\n]",data->pers.name);
	scanf("%c",&ch);
	printf("\n Enter Address: ");
	scanf("%[^\n]",data->pers.address);
	printf("\n Enter Contact: ");
	scanf("%d",&data->pers.phone);
	data->next = NULL;
	data->prev = NULL;

	if(head == NULL)
	{
		head = data;
	}
	else
	{
		temp = head;
		while(temp->next != NULL)
		{
			temp = temp->next;
		}

		temp->next = data;
		data->prev = temp;
	}

}
void add_first(detail *usr)
{
	int i;
	char ch;
	detail *data = (detail *)malloc(sizeof(detail));
	printf("\n Enter Id: ");
	scanf("%d",&data->id);
	scanf("%c",&ch);
	printf("\n Enter Acc Type: ");
	scanf("%s",data->type);
	printf("\n Enter Balance: ");
	scanf("%d",&data->balance);
	scanf("%c",&ch);
	printf("\n Enter Name: ");
	scanf("%[^\n]",data->pers.name);
	scanf("%c",&ch);
	printf("\n Enter Address: ");
	scanf("%[^\n]",data->pers.address);
	printf("\n Enter Contact: ");
	scanf("%d",&data->pers.phone);
	data->next = NULL;
	data->prev = NULL;

	 if(head == NULL)
      {
          head = data;
      }
      else
      {
		  data->next = head;
          head->prev = data;
		  head = data;

      }


}
void display_fwd()
{
	temp = head;
	printf("\n ID \tType \tBalance \tName\t \t Address\t  \t Contact");
	while(temp != NULL)
	{
		printf("\n %d \t%s \t %d \t%s   \t%s \t %d",temp->id,temp->type,temp->balance,temp->pers.name,temp->pers.address,temp->pers.phone);
		temp = temp->next;
	}
}
void display_back()
{
	 temp = head;
	 while(temp->next != NULL)
	 {
		 temp = temp->next;
	 }
     printf("\n ID \tType \tBalance \tName\t \t Address\t  \t Contact");
     while(temp != NULL)
     {
         printf("\n %d \t%s \t %d \t%s   \t%s \t %d",temp->id,temp->type,temp->balance,temp->pers.name,temp->pers.address,temp->pers.phone);
         temp = temp->prev;
     }
}
